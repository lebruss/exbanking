to Yolo Group
re: Automation QA for Fraud Development

Hello,

This is a plain JavaScript app I made with Node. server.js will start the server, I tested it with Postman. I first attempted this assignment with the preferred Protobuf but sent it in this format so I could have a working result. I made this in my Ubuntu virtual machine without online hosting, so everything related to the application runs on localhost via port 3000.

I don't have a presentation for Non-Functional Test Cases for my task, but I understand the topic better now.

Thank you,
Caleb