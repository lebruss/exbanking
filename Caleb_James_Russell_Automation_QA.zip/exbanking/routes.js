const fs = require('fs');
const dataPath = './data/users.json';

function handleRequest(request, response) {
    let body = [];
    request.on('data', (chunk) => {
        body.push(chunk);
    }).on('end', () => {
        body = Buffer.concat(body).toString();
        
        switch(request.url) {
            case "/create_user":
                createUser(body, response);
                break;
            case "/deposit":
                deposit(body, response);
                break;
            case "/withdraw":
                withdraw(body, response);
                break;
            case "/get_balance":
                getBalance(body, response);
                break;
            case "/send":
                send(body, response);
                break;
            default:
                response.writeHead(404);
                response.end(JSON.stringify({ message: "Resource not found" }));
        }
    });
}

function createUser(body, response) {
    const { username, password } = JSON.parse(body);
    const users = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    if (users[username]) {
        response.writeHead(400);
        response.end(JSON.stringify({ message: "Username already exists" }));
        return;
    }
    users[username] = { password, balance: 0 };
    fs.writeFileSync(dataPath, JSON.stringify(users, null, 2));
    response.writeHead(200);
    response.end(JSON.stringify({ message: "User created" }));
}

function deposit(body, response) {
    const { username, amount } = JSON.parse(body);
    const users = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    if (!users[username]) {
        response.writeHead(404);
        response.end(JSON.stringify({ message: "User not found" }));
        return;
    }
    if (amount <= 0) {
        response.writeHead(400);
        response.end(JSON.stringify({ message: "Invalid deposit amount" }));
        return;
    }
    users[username].balance += amount;
    fs.writeFileSync(dataPath, JSON.stringify(users, null, 2));
    response.writeHead(200);
    response.end(JSON.stringify({ message: "Deposit successful" }));
}

function withdraw(body, response) {
    const { username, amount } = JSON.parse(body);
    const users = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    if (!users[username]) {
        response.writeHead(404);
        response.end(JSON.stringify({ message: "User not found" }));
        return;
    }
    if (users[username].balance < amount || amount <= 0) {
        response.writeHead(400);
        response.end(JSON.stringify({ message: "Invalid withdrawal amount" }));
        return;
    }
    users[username].balance -= amount;
    fs.writeFileSync(dataPath, JSON.stringify(users, null, 2));
    response.writeHead(200);
    response.end(JSON.stringify({ message: "Withdrawal successful" }));
}

function getBalance(body, response) {
    const { username } = JSON.parse(body);
    const users = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    if (!users[username]) {
        response.writeHead(404);
        response.end(JSON.stringify({ message: "User not found" }));
        return;
    }
    response.writeHead(200);
    response.end(JSON.stringify({ balance: users[username].balance }));
}

function send(body, response) {
    const { fromUser, toUser, amount } = JSON.parse(body);
    const users = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    if (!users[fromUser] || !users[toUser]) {
        response.writeHead(404);
        response.end(JSON.stringify({ message: "User not found" }));
        return;
    }
    if (users[fromUser].balance < amount || amount <= 0) {
        response.writeHead(400);
        response.end(JSON.stringify({ message: "Invalid transfer amount" }));
        return;
    }
    users[fromUser].balance -= amount;
    users[toUser].balance += amount;
    fs.writeFileSync(dataPath, JSON.stringify(users, null, 2));
    response.writeHead(200);
    response.end(JSON.stringify({ message: "Transfer successful" }));
}

module.exports = { handleRequest };

